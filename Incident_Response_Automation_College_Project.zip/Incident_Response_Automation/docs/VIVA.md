# Viva questions and answers

1. **What is this project's objective?** To automate local incident triage and response workflows from imported alerts, while retaining approval decisions and review history.
2. **What is the difference between an alert and an incident here?** An alert is a structured input record. Each new accepted event ID creates one incident with a severity, workflow state and action list.
3. **What is a playbook?** A predefined sequence of response steps associated with a type of alert. Here it captures alert metadata, creates a local notification and may request simulated containment.
4. **What is actually automated?** Validation, duplicate handling, severity assignment, task creation, local notification records, workflow transitions, audit entries and reports.
5. **Are devices really isolated or IPs blocked?** No. Containment creates explicitly labeled simulation receipts only. No operating-system command or external security API runs.
6. **How is severity calculated?** Fixed rules map malware alerts to critical, phishing and five-or-more login failures to high, suspicious processes to medium, and fewer login failures to low.
7. **Does the system detect attacks directly?** No. It handles alerts supplied by an upstream producer. It does not inspect email contents, execute malware or collect network traffic.
8. **How are duplicate alerts handled?** A unique event ID identifies each alert. Identical canonical payloads are skipped; conflicting payloads under the same ID reject the batch.
9. **Why use SQLite?** It provides local persistent relational storage and transactions without a separate database server, suitable for a classroom prototype.
10. **What are transactions used for?** They prevent partial imports and keep incident state changes, action updates and corresponding audit entries consistent.
11. **What is the approval mechanism?** A waiting incident needs a nonempty review note before its containment simulation can run. It is a workflow control, not authenticated role separation.
12. **What is the workflow?** High/critical cases move from WAITING_APPROVAL to SIMULATED_CONTAINMENT to CLOSED. Low/medium cases move from READY_REVIEW to CLOSED.
13. **Can audit history be tampered with?** Yes, by someone with access to edit the database. The application provides a history but does not implement immutable or signed logging.
14. **How do you reduce SQL and CSV injection risks?** SQL uses parameter binding. Exported text with spreadsheet-formula prefixes receives an apostrophe. The interface treats alert contents as text.
15. **How was it tested?** Fourteen automated tests cover thresholds, task creation, deduplication, rollback, validation, approval, closure, persistence and CSV handling. The demo exercises a complete incident lifecycle.
16. **What would you improve?** Authentication, separate approvers, protected audit storage, integration with authorized security tools, real evidence collection, asynchronous jobs, retries and incident correlation.

## Two minute presentation

My project is an Incident Response Automation Platform implemented in Python with a Tkinter interface and SQLite storage. It demonstrates how a security team can organize response work after receiving an alert.

When an alert is imported, the system validates it, checks its event ID, assigns a rule-based severity and creates an incident. The selected playbook records the supplied alert and creates a local notification. High-priority playbooks wait for an operator review before simulated containment is allowed.

I will import five fictional alerts covering login failures, malware, phishing and a suspicious process. Importing the same alerts again does not create duplicates. I will select a high-priority incident, review its planned actions, approve the simulation and close the incident with a note. The audit timeline shows these successful transitions, and the incident list can be exported as CSV.

All containment is simulated, so the project does not affect external systems. Its main contribution is the consistent local workflow and traceable review history. Fourteen tests support the implemented behavior. Real-world deployment would require authenticated roles, protected logs, trusted integrations and additional operational testing.
